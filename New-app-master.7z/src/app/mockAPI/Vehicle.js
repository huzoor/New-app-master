var VehicleData = {
  "count": 1,
  "next": null,
  "results": [
    {
      "vehicle_id": 310200000002395202,
      "certified_used": "N",
      "chrome_make": "Acura",
      "vin": 370,
      "model_number": "Sedan",
      "odometer": 500,
      "stock_no": null,
      "chrome_year": 2017,
      "chrome_trim": "Sedan",
      "chrome_style_id": null,
      "chrome_model": "ILX"
    }
  ],
  "previous": null
}

module.export = VehicleData;