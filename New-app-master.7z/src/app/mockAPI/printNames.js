var printNames = {
    "count": 1,
    "next": null,
    "results": [
        {
            "first_name": "vito",
            "last_name": "user",
            "zipcode": "11042",
            "phone": null,
            "customer_id": 310200000002509000,
            "email": null
        }
    ],
    "previous": null
}

module.export = printNames;