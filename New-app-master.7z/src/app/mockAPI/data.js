export default {
    Questions: [
        {
            caption: 'This is where the first P1question would go?',
            choices: [
                {
                    caption: 'opt1',
                    value: 'OPT1'
                },
                {
                    caption: 'opt2',
                    value: 'OPT2'
                },
                {
                    caption: 'opt3',
                    value: 'OPT3'
                }
            ]
        },
        {
            caption: 'This is where the second P1question would go, if user have more questions to ask?',
            choices: [
                {
                    caption: 'Yes',
                    value: 'OPT1'
                },
                {
                    caption: 'No',
                    value: 'OPT2'
                }
            ]
        },
        {
            caption: 'This is where the third P1question would go',
            choices: [
                {
                    caption: 'Ford',
                    value: 'OPT1'
                },
                {
                    caption: 'Benz',
                    value: 'OPT2'
                },
                {
                    caption: 'Jeep',
                    value: 'OPT3'
                }
            ]
        },
        {
            caption: 'This is where the fourth P1question would go',
            choices: [
                {
                    caption: 'Yes',
                    value: 'OPT1'
                },
                {
                    caption: 'No',
                    value: 'OPT2'
                }
            ]
        }
    ]
}