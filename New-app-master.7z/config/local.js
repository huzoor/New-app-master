const localConfig = {

  emenuMobileGatewayAPI: 'http://10.117.0.61:6333/api/mobile/v1/emenu',
  dealMobileGatewayAPI: 'http://10.117.0.61:6333/api/mobile/v1/deal',
  baseUrlPath: 'http://localhost',
  presentationPortAPI: ':6357',
  printPortAPI: ':6127',
  fniMenuDealerApp: '',
  fniMenuCustApp: '',
  version: '',
  credentialsFlag: false
}

module.exports = localConfig;
