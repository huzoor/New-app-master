const tsConfig = {
  emenuMobileGatewayAPI: 'http://10.117.0.61:6333/api/mobile/v1/emenu',
  dealMobileGatewayAPI: 'http://10.117.0.61:6333/api/mobile/v1/deal',
  baseUrlPath: 'http://localhost',
  fniMenuDealerApp: '',
  fniMenuCustApp:'',
  version: '',
  presentationPortAPI: ':6357',
  printPortAPI: ':6127',
  credentialsFlag: false
}

module.exports = tsConfig;
