# dt-menu-app

 $ git clone https://github.dev.dealertrack.com/DT2-Payment-NYIlluminati/dt-menu-app

 $ npm install

 $npm run start
